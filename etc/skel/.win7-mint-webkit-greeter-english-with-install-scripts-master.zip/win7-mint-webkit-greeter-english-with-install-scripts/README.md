# Winux7 LightDM Theme

This is a fork from project ailtonbsj/win7-mint-webkit-greeter. It is a greeter with style of Windows 7.

![](screenshot.png)

# How to install on Cinnamon

```bash
git clone https://github.com/ImGGAAVVIINN/win7-mint-webkit-greeter-english-with-install-scripts.git
cd win7-mint-webkit-greeter
chmod +x installer.sh
./installer.sh

```


