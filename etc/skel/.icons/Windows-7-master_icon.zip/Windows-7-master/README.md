# Windows Se7en Icon Theme
### Port of the original Win2-7 icon theme adjusted to work with GTK 3.18 +

![folder](https://github.com/B00merang-Artwork/Windows-7/blob/master/filesystems/folder.png)
---
Credits: https://www.gnome-look.org/content/show.php/Win2-7+Pack?content=113264
